package com.qiang.springvue.entity;

import lombok.Data;

@Data
public class Book {
    private Integer id;
    private String name;
    private String author;
}

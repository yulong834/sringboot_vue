package com.qiang.springvue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringVueApplicationTests {

    @Test
    void contextLoads() {
    }

}
